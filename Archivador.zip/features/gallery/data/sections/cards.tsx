import type { Section } from "../../types"

export const cardsSection: Section = {
  id: "cards",
  name: "Cards",
  collections: [
    {
      id: "profile-cards",
      title: "Profile Cards",
      description: "User profile cards with avatars and information",
      variants: [
        {
          id: "simple-profile",
          title: "Simple Profile Card",
          description: "Basic user profile with avatar and bio",
          tags: ["profile", "user", "avatar"],
          preview: (
            <div className="max-w-sm rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
              <div className="flex items-center gap-4">
                <div className="h-16 w-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-600"></div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Jane Doe</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Product Designer</p>
                </div>
              </div>
              <p className="mt-4 text-sm text-gray-600 dark:text-gray-300">
                Passionate about creating beautiful and functional user experiences.
              </p>
            </div>
          ),
          code: `<div className="max-w-sm rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
  <div className="flex items-center gap-4">
<div className="h-16 w-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-600"></div>
<div>
  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Jane Doe</h3>
  <p className="text-sm text-gray-500 dark:text-gray-400">Product Designer</p>
</div>
  </div>
  <p className="mt-4 text-sm text-gray-600 dark:text-gray-300">
Passionate about creating beautiful and functional user experiences.
  </p>
</div>`,
        },
        {
          id: "profile-with-stats",
          title: "Profile Card with Stats",
          description: "Profile card displaying user statistics",
          tags: ["profile", "stats", "metrics"],
          preview: (
            <div className="max-w-sm rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
              <div className="flex flex-col items-center text-center">
                <div className="h-20 w-20 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600"></div>
                <h3 className="mt-4 text-xl font-bold text-gray-900 dark:text-white">Alex Smith</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Full Stack Developer</p>
              </div>
              <div className="mt-6 grid grid-cols-3 gap-4 border-t border-gray-200 pt-4 dark:border-gray-700">
                <div className="text-center">
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">128</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Projects</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">1.2k</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Followers</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">342</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Following</p>
                </div>
              </div>
            </div>
          ),
          code: `<div className="max-w-sm rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
  <div className="flex flex-col items-center text-center">
<div className="h-20 w-20 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600"></div>
<h3 className="mt-4 text-xl font-bold text-gray-900 dark:text-white">Alex Smith</h3>
<p className="text-sm text-gray-500 dark:text-gray-400">Full Stack Developer</p>
  </div>
  <div className="mt-6 grid grid-cols-3 gap-4 border-t border-gray-200 pt-4 dark:border-gray-700">
<div className="text-center">
  <p className="text-2xl font-bold text-gray-900 dark:text-white">128</p>
  <p className="text-xs text-gray-500 dark:text-gray-400">Projects</p>
</div>
<div className="text-center">
  <p className="text-2xl font-bold text-gray-900 dark:text-white">1.2k</p>
  <p className="text-xs text-gray-500 dark:text-gray-400">Followers</p>
</div>
<div className="text-center">
  <p className="text-2xl font-bold text-gray-900 dark:text-white">342</p>
  <p className="text-xs text-gray-500 dark:text-gray-400">Following</p>
</div>
  </div>
</div>`,
        },
        {
          id: "profile-with-actions",
          title: "Profile Card with Actions",
          description: "Interactive profile card with action buttons",
          tags: ["profile", "actions", "buttons"],
          preview: (
            <div className="max-w-sm rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
              <div className="flex items-start gap-4">
                <div className="h-16 w-16 flex-shrink-0 rounded-full bg-gradient-to-br from-pink-500 to-rose-600"></div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Sarah Wilson</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">UX Designer</p>
                  <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">
                    Creating delightful user experiences through design thinking and research.
                  </p>
                </div>
              </div>
              <div className="mt-4 flex gap-2">
                <button className="flex-1 rounded-lg bg-blue-500 px-4 py-2 text-sm font-medium text-white hover:bg-blue-600">
                  Follow
                </button>
                <button className="flex-1 rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700">
                  Message
                </button>
              </div>
            </div>
          ),
          code: `<div className="max-w-sm rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
  <div className="flex items-start gap-4">
<div className="h-16 w-16 flex-shrink-0 rounded-full bg-gradient-to-br from-pink-500 to-rose-600"></div>
<div className="flex-1">
  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Sarah Wilson</h3>
  <p className="text-sm text-gray-500 dark:text-gray-400">UX Designer</p>
  <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">
    Creating delightful user experiences through design thinking and research.
  </p>
</div>
  </div>
  <div className="mt-4 flex gap-2">
<button className="flex-1 rounded-lg bg-blue-500 px-4 py-2 text-sm font-medium text-white hover:bg-blue-600">
  Follow
</button>
<button className="flex-1 rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700">
  Message
</button>
  </div>
</div>`,
        },
      ],
    },
    {
      id: "pricing-cards",
      title: "Pricing Cards",
      description: "Pricing plan cards for subscriptions and services",
      variants: [
        {
          id: "basic-pricing",
          title: "Basic Pricing Card",
          description: "Simple pricing card with features list",
          tags: ["pricing", "subscription", "plan"],
          preview: (
            <div className="max-w-sm rounded-lg border-2 border-blue-500 bg-white p-6 shadow-lg dark:bg-gray-800">
              <div className="mb-4">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Pro Plan</h3>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="text-4xl font-bold text-gray-900 dark:text-white">$29</span>
                  <span className="text-gray-500 dark:text-gray-400">/month</span>
                </div>
              </div>
              <ul className="mb-6 space-y-2">
                <li className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                  <svg className="h-5 w-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Unlimited projects
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                  <svg className="h-5 w-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Priority support
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                  <svg className="h-5 w-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Advanced analytics
                </li>
              </ul>
              <button className="w-full rounded-lg bg-blue-500 px-4 py-2 font-semibold text-white transition-colors hover:bg-blue-600">
                Get Started
              </button>
            </div>
          ),
          code: `<div className="max-w-sm rounded-lg border-2 border-blue-500 bg-white p-6 shadow-lg dark:bg-gray-800">
  <div className="mb-4">
<h3 className="text-2xl font-bold text-gray-900 dark:text-white">Pro Plan</h3>
<div className="mt-2 flex items-baseline gap-1">
  <span className="text-4xl font-bold text-gray-900 dark:text-white">$29</span>
  <span className="text-gray-500 dark:text-gray-400">/month</span>
</div>
  </div>
  <ul className="mb-6 space-y-2">
<li className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
  <svg className="h-5 w-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
  </svg>
  Unlimited projects
</li>
<li className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
  <svg className="h-5 w-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
  </svg>
  Priority support
</li>
<li className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
  <svg className="h-5 w-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
  </svg>
  Advanced analytics
</li>
  </ul>
  <button className="w-full rounded-lg bg-blue-500 px-4 py-2 font-semibold text-white transition-colors hover:bg-blue-600">
Get Started
  </button>
</div>`,
        },
        {
          id: "featured-pricing",
          title: "Featured Pricing Card",
          description: "Highlighted pricing card with badge",
          tags: ["pricing", "featured", "badge"],
          preview: (
            <div className="max-w-sm rounded-lg border-2 border-purple-500 bg-gradient-to-br from-purple-50 to-pink-50 p-6 shadow-xl dark:from-purple-950 dark:to-pink-950">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Enterprise</h3>
                <span className="rounded-full bg-purple-500 px-3 py-1 text-xs font-semibold text-white">
                  Popular
                </span>
              </div>
              <div className="mb-4">
                <div className="flex items-baseline gap-1">
                  <span className="text-5xl font-bold text-gray-900 dark:text-white">$99</span>
                  <span className="text-gray-500 dark:text-gray-400">/month</span>
                </div>
                <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">Everything you need for your team</p>
              </div>
              <ul className="mb-6 space-y-3">
                <li className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-200">
                  <svg className="h-5 w-5 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Unlimited everything
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-200">
                  <svg className="h-5 w-5 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  24/7 Priority support
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-200">
                  <svg className="h-5 w-5 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Advanced security
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-200">
                  <svg className="h-5 w-5 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Custom integrations
                </li>
              </ul>
              <button className="w-full rounded-lg bg-purple-500 px-4 py-3 font-semibold text-white transition-colors hover:bg-purple-600">
                Start Free Trial
              </button>
            </div>
          ),
          code: `<div className="max-w-sm rounded-lg border-2 border-purple-500 bg-gradient-to-br from-purple-50 to-pink-50 p-6 shadow-xl dark:from-purple-950 dark:to-pink-950">
  <div className="mb-4 flex items-center justify-between">
<h3 className="text-2xl font-bold text-gray-900 dark:text-white">Enterprise</h3>
<span className="rounded-full bg-purple-500 px-3 py-1 text-xs font-semibold text-white">Popular</span>
  </div>
  <div className="mb-4">
<div className="flex items-baseline gap-1">
  <span className="text-5xl font-bold text-gray-900 dark:text-white">$99</span>
  <span className="text-gray-500 dark:text-gray-400">/month</span>
</div>
<p className="mt-2 text-sm text-gray-600 dark:text-gray-300">Everything you need for your team</p>
  </div>
  <ul className="mb-6 space-y-3">
<li className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-200">
  <svg className="h-5 w-5 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
  </svg>
  Unlimited everything
</li>
<li className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-200">
  <svg className="h-5 w-5 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
  </svg>
  24/7 Priority support
</li>
<li className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-200">
  <svg className="h-5 w-5 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
  </svg>
  Advanced security
</li>
<li className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-200">
  <svg className="h-5 w-5 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
  </svg>
  Custom integrations
</li>
  </ul>
  <button className="w-full rounded-lg bg-purple-500 px-4 py-3 font-semibold text-white transition-colors hover:bg-purple-600">
Start Free Trial
  </button>
</div>`,
        },
        {
          id: "comparison-pricing",
          title: "Comparison Pricing Card",
          description: "Pricing card with comparison features",
          tags: ["pricing", "comparison", "features"],
          preview: (
            <div className="max-w-sm rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Starter</h3>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-4xl font-bold text-gray-900 dark:text-white">$0</span>
                <span className="text-gray-500 dark:text-gray-400">/month</span>
              </div>
              <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">Perfect for trying out our service</p>
              <ul className="mt-6 space-y-3">
                <li className="flex items-start gap-2">
                  <svg
                    className="mt-0.5 h-5 w-5 flex-shrink-0 text-green-500"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-sm text-gray-600 dark:text-gray-300">Up to 5 projects</span>
                </li>
                <li className="flex items-start gap-2">
                  <svg
                    className="mt-0.5 h-5 w-5 flex-shrink-0 text-green-500"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-sm text-gray-600 dark:text-gray-300">Basic analytics</span>
                </li>
                <li className="flex items-start gap-2">
                  <svg
                    className="mt-0.5 h-5 w-5 flex-shrink-0 text-gray-300"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                  <span className="text-sm text-gray-400 line-through dark:text-gray-500">Priority support</span>
                </li>
                <li className="flex items-start gap-2">
                  <svg
                    className="mt-0.5 h-5 w-5 flex-shrink-0 text-gray-300"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                  <span className="text-sm text-gray-400 line-through dark:text-gray-500">Custom integrations</span>
                </li>
              </ul>
              <button className="mt-6 w-full rounded-lg border border-gray-300 px-4 py-2 font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700">
                Get Started
              </button>
            </div>
          ),
          code: `<div className="max-w-sm rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-700 dark:bg-gray-800">
  <h3 className="text-xl font-bold text-gray-900 dark:text-white">Starter</h3>
  <div className="mt-4 flex items-baseline gap-1">
<span className="text-4xl font-bold text-gray-900 dark:text-white">$0</span>
<span className="text-gray-500 dark:text-gray-400">/month</span>
  </div>
  <p className="mt-2 text-sm text-gray-600 dark:text-gray-300">Perfect for trying out our service</p>
  <ul className="mt-6 space-y-3">
<li className="flex items-start gap-2">
  <svg className="mt-0.5 h-5 w-5 flex-shrink-0 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
  </svg>
  <span className="text-sm text-gray-600 dark:text-gray-300">Up to 5 projects</span>
</li>
<li className="flex items-start gap-2">
  <svg className="mt-0.5 h-5 w-5 flex-shrink-0 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
  </svg>
  <span className="text-sm text-gray-600 dark:text-gray-300">Basic analytics</span>
</li>
<li className="flex items-start gap-2">
  <svg className="mt-0.5 h-5 w-5 flex-shrink-0 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
  </svg>
  <span className="text-sm text-gray-400 line-through dark:text-gray-500">Priority support</span>
</li>
<li className="flex items-start gap-2">
  <svg className="mt-0.5 h-5 w-5 flex-shrink-0 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
  </svg>
  <span className="text-sm text-gray-400 line-through dark:text-gray-500">Custom integrations</span>
</li>
  </ul>
  <button className="mt-6 w-full rounded-lg border border-gray-300 px-4 py-2 font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700">
Get Started
  </button>
</div>`,
        },
      ],
    },
    {
  id: "booking-cards",
  title: "Booking Cards",
  description: "Cards con imagen de fondo, overlay y CTA estilo booking",
  variants: [
    {
      id: "santorini-villa",
      title: "Santorini Villa (Overlay + Hover)",
      description: "Diseño tipo booking con gradiente inferior y micro-interacciones",
      tags: ["travel", "booking", "image", "cta", "hover"],
      preview: (
        <div className="group relative w-[340px] overflow-hidden rounded-[36px] bg-zinc-900 shadow-2xl ring-1 ring-black/10 transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_28px_70px_-18px_rgba(0,0,0,0.55)]">
          {/* Frame tipo “tarjeta/telefono” */}
          <div className="absolute inset-0 rounded-[36px] bg-white/5 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

          <div className="relative aspect-[3/5] w-full">
            {/* Imagen */}
            <img
              src="/cards/santorini-card-bg.jpg"
              alt="Santorini Villa"
              className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.06]"
            />

            {/* Vignette suave */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,0,0,0)_35%,rgba(0,0,0,0.35)_100%)] opacity-80 transition-opacity duration-300 group-hover:opacity-90" />

            {/* Gradiente inferior (clave para que se vea como tu diseño) */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/0 via-black/10 to-black/85 transition-opacity duration-300 group-hover:opacity-95" />

            {/* Contenido */}
            <div className="absolute inset-x-0 bottom-0 p-6">
              <h3 className="text-[28px] font-semibold tracking-tight text-white drop-shadow">
                Santorini Villa
              </h3>

              <p className="mt-2 text-sm leading-relaxed text-white/80">
                Luxury villa overlooking the Aegean Sea, offering breathtaking sunset views and a private infinity
                pool for ultimate relaxation.
              </p>

              {/* Chips */}
              <div className="mt-4 flex flex-wrap gap-3">
                <div className="flex items-center gap-2 rounded-full bg-white/12 px-4 py-2 text-white/90 backdrop-blur-md transition-colors duration-300 group-hover:bg-white/16">
                  <span className="text-sm font-semibold">4.5</span>
                  <div className="flex items-center gap-1 text-xs">
                    <span className="text-white">★</span>
                    <span className="text-white">★</span>
                    <span className="text-white">★</span>
                    <span className="text-white">★</span>
                    <span className="text-white/35">★</span>
                  </div>
                </div>

                <div className="rounded-full bg-white/12 px-4 py-2 text-sm text-white/90 backdrop-blur-md transition-colors duration-300 group-hover:bg-white/16">
                  3 Night Stay
                </div>
              </div>

              {/* Botón */}
              <button className="mt-5 w-full rounded-full bg-white py-4 text-sm font-semibold text-zinc-900 shadow-lg transition-all duration-300 hover:bg-white/95 active:scale-[0.99] group-hover:translate-y-0">
                Reserve now
              </button>
            </div>
          </div>
        </div>
      ),
      code: `// Coloca la imagen en: public/cards/santorini-card-bg.jpg
<div className="group relative w-[340px] overflow-hidden rounded-[36px] bg-zinc-900 shadow-2xl ring-1 ring-black/10 transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_28px_70px_-18px_rgba(0,0,0,0.55)]">
  <div className="absolute inset-0 rounded-[36px] bg-white/5 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

  <div className="relative aspect-[3/5] w-full">
    <img
      src="/cards/santorini-card-bg.jpg"
      alt="Santorini Villa"
      className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.06]"
    />

    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,0,0,0)_35%,rgba(0,0,0,0.35)_100%)] opacity-80 transition-opacity duration-300 group-hover:opacity-90" />
    <div className="absolute inset-0 bg-gradient-to-b from-black/0 via-black/10 to-black/85 transition-opacity duration-300 group-hover:opacity-95" />

    <div className="absolute inset-x-0 bottom-0 p-6">
      <h3 className="text-[28px] font-semibold tracking-tight text-white drop-shadow">Santorini Villa</h3>

      <p className="mt-2 text-sm leading-relaxed text-white/80">
        Luxury villa overlooking the Aegean Sea, offering breathtaking sunset views and a private infinity pool for ultimate relaxation.
      </p>

      <div className="mt-4 flex flex-wrap gap-3">
        <div className="flex items-center gap-2 rounded-full bg-white/12 px-4 py-2 text-white/90 backdrop-blur-md transition-colors duration-300 group-hover:bg-white/16">
          <span className="text-sm font-semibold">4.5</span>
          <div className="flex items-center gap-1 text-xs">
            <span className="text-white">★</span><span className="text-white">★</span><span className="text-white">★</span><span className="text-white">★</span><span className="text-white/35">★</span>
          </div>
        </div>

        <div className="rounded-full bg-white/12 px-4 py-2 text-sm text-white/90 backdrop-blur-md transition-colors duration-300 group-hover:bg-white/16">
          3 Night Stay
        </div>
      </div>

      <button className="mt-5 w-full rounded-full bg-white py-4 text-sm font-semibold text-zinc-900 shadow-lg transition-all duration-300 hover:bg-white/95 active:scale-[0.99]">
        Reserve now
      </button>
    </div>
  </div>
</div>`,
    },
  ],
},

  ],
}
