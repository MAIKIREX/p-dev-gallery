import BrowseDashboard from "@/features/gallery/components/BrowseDashboard"

export default function GalleryPage() {
  return <BrowseDashboard />
}
