"use client"

import type React from "react"

import { Highlight, defaultProps, themes } from "prism-react-renderer"
import { useState, useMemo } from "react"

// Data model types
interface GalleryItem {
  id: string
  title: string
  description: string
  tags: string[]
  preview: React.ReactNode
  code: string
}

interface Section {
  id: string
  label: string
  items: GalleryItem[]
}

// Helper Components
function Sidebar({
  sections,
  activeSection,
  onSectionChange,
}: {
  sections: Section[]
  activeSection: string
  onSectionChange: (id: string) => void
}) {
  return (
    <aside className="sticky top-0 h-screen w-64 border-r border-border bg-card p-6">
      <h2 className="mb-6 text-sm font-semibold uppercase tracking-wide text-muted-foreground">Categories</h2>
      <nav className="space-y-1">
        {sections.map((section) => (
          <button
            key={section.id}
            onClick={() => onSectionChange(section.id)}
            disabled={section.items.length === 0}
            className={`w-full rounded-lg px-4 py-2 text-left text-sm font-medium transition-colors ${
              activeSection === section.id
                ? "bg-primary text-primary-foreground"
                : section.items.length === 0
                  ? "cursor-not-allowed text-muted-foreground opacity-50"
                  : "text-foreground hover:bg-accent"
            }`}
          >
            {section.label}
            {section.items.length === 0 && <span className="ml-2 text-xs">(Coming soon)</span>}
          </button>
        ))}
      </nav>
    </aside>
  )
}

function CodeBlock({ code, onCopy }: { code: string; onCopy: () => void }) {
  return (
    <div className="relative min-w-0">
      <Highlight {...defaultProps} code={code} language="tsx" theme={themes.dracula}>
        {({ className, style, tokens, getLineProps, getTokenProps }) => (
          <pre
            className={`${className} w-full max-w-full overflow-x-auto rounded-lg p-4 text-xs leading-relaxed`}
            style={style}
          >
            <code className="block w-max min-w-full font-mono">
              {tokens.map((line, i) => (
                <div key={i} {...getLineProps({ line, key: i })}>
                  {line.map((token, key) => (
                    <span key={key} {...getTokenProps({ token, key })} />
                  ))}
                </div>
              ))}
            </code>
          </pre>
        )}
      </Highlight>
      <button
        onClick={onCopy}
        className="absolute right-2 top-2 rounded bg-primary px-3 py-1 text-xs font-medium text-primary-foreground transition-colors hover:bg-primary/90"
      >
        Copy
      </button>
    </div>
  )
}

function DemoCard({ item }: { item: GalleryItem }) {
  const [showCode, setShowCode] = useState(false)
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(item.code)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch (err) {
      console.error("Failed to copy:", err)
    }
  }

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card shadow-sm">
      {/* Preview Panel */}
      <div className="border-b border-border bg-muted/30 p-8">
        <div className="flex items-center justify-center">{item.preview}</div>
      </div>

      {/* Info Panel */}
      <div className="p-4">
        <div className="mb-3">
          <h3 className="text-lg font-semibold text-foreground">{item.title}</h3>
          <p className="mt-1 text-sm text-muted-foreground">{item.description}</p>
        </div>

        {/* Tags */}
        <div className="mb-3 flex flex-wrap gap-2">
          {item.tags.map((tag) => (
            <span
              key={tag}
              className="rounded-full bg-secondary px-2.5 py-0.5 text-xs font-medium text-secondary-foreground"
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          <button
            onClick={() => setShowCode(!showCode)}
            className="flex-1 rounded-lg border border-border bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            {showCode ? "Hide Code" : "Show Code"}
          </button>
          <button
            onClick={handleCopy}
            className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            {copied ? "Copied!" : "Copy Code"}
          </button>
        </div>

        {/* Code Panel (Collapsible) */}
        {showCode && (
          <div className="mt-4">
            <CodeBlock code={item.code} onCopy={handleCopy} />
          </div>
        )}
      </div>
    </div>
  )
}

function GalleryGrid({
  items,
  activeTags,
  onTagToggle,
}: {
  items: GalleryItem[]
  activeTags: string[]
  onTagToggle: (tag: string) => void
}) {
  // Extract unique tags from items
  const allTags = useMemo(() => {
    const tags = new Set<string>()
    items.forEach((item) => item.tags.forEach((tag) => tags.add(tag)))
    return Array.from(tags)
  }, [items])

  return (
    <div>
      {/* Tag Filter Row */}
      {allTags.length > 0 && (
        <div className="mb-6 flex flex-wrap gap-2">
          <span className="text-sm font-medium text-muted-foreground">Filter:</span>
          {allTags.map((tag) => (
            <button
              key={tag}
              onClick={() => onTagToggle(tag)}
              className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
                activeTags.includes(tag)
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      )}

      {/* Grid */}
      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
        {items.map((item) => (
          <DemoCard key={item.id} item={item} />
        ))}
      </div>
    </div>
  )
}

// Example Card Components (Preview)
function ProfileCard() {
  return (
    <div className="w-80 rounded-xl border border-zinc-200 bg-white p-6 shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
      <div className="flex flex-col items-center">
        <div className="h-20 w-20 rounded-full bg-gradient-to-br from-blue-500 to-purple-600" />
        <h3 className="mt-4 text-xl font-semibold text-zinc-900 dark:text-zinc-100">Jane Doe</h3>
        <p className="text-sm text-zinc-600 dark:text-zinc-400">Senior Designer</p>
        <div className="mt-6 flex w-full gap-2">
          <button className="flex-1 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-700">
            Follow
          </button>
          <button className="flex-1 rounded-lg border border-zinc-300 bg-white px-4 py-2 text-sm font-medium text-zinc-900 transition-colors hover:bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-100 dark:hover:bg-zinc-700">
            Message
          </button>
        </div>
      </div>
    </div>
  )
}

function PricingCard() {
  return (
    <div className="w-80 rounded-xl border border-zinc-200 bg-white p-6 shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-zinc-900 dark:text-zinc-100">Professional</h3>
        <div className="mt-2 flex items-baseline">
          <span className="text-4xl font-bold text-zinc-900 dark:text-zinc-100">$29</span>
          <span className="ml-1 text-zinc-600 dark:text-zinc-400">/month</span>
        </div>
      </div>
      <ul className="mb-6 space-y-3">
        {["Unlimited projects", "Advanced analytics", "24/7 Support", "Custom domain"].map((feature) => (
          <li key={feature} className="flex items-center text-sm text-zinc-700 dark:text-zinc-300">
            <svg className="mr-2 h-4 w-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            {feature}
          </li>
        ))}
      </ul>
      <button className="w-full rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-blue-700">
        Get Started
      </button>
    </div>
  )
}

function StatsCard() {
  const stats = [
    { label: "Users", value: "12.5K" },
    { label: "Revenue", value: "$48K" },
    { label: "Growth", value: "+23%" },
  ]

  return (
    <div className="w-80 rounded-xl border border-zinc-200 bg-gradient-to-br from-blue-50 to-purple-50 p-6 shadow-sm dark:from-zinc-900 dark:to-zinc-800 dark:border-zinc-700">
      <h3 className="mb-6 text-lg font-semibold text-zinc-900 dark:text-zinc-100">Performance</h3>
      <div className="grid grid-cols-3 gap-4">
        {stats.map((stat) => (
          <div key={stat.label} className="text-center">
            <div className="mb-1 text-2xl font-bold text-zinc-900 dark:text-zinc-100">{stat.value}</div>
            <div className="text-xs text-zinc-600 dark:text-zinc-400">{stat.label}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

function BlogCard() {
  return (
    <div className="w-80 overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
      <div className="h-40 bg-gradient-to-br from-orange-400 to-pink-500" />
      <div className="p-4">
        <span className="inline-block rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-800 dark:bg-blue-900 dark:text-blue-200">
          Design
        </span>
        <h3 className="mt-2 text-lg font-semibold text-zinc-900 dark:text-zinc-100">Building Better Interfaces</h3>
        <p className="mt-2 text-sm text-zinc-600 dark:text-zinc-400">
          Learn the fundamentals of creating user-friendly and accessible web interfaces with modern design principles.
        </p>
        <div className="mt-4 flex items-center justify-between text-xs text-zinc-500 dark:text-zinc-500">
          <span>5 min read</span>
          <span>Dec 17, 2025</span>
        </div>
      </div>
    </div>
  )
}

function CTACard() {
  return (
    <div className="w-80 rounded-xl border border-zinc-200 bg-gradient-to-br from-indigo-600 to-purple-600 p-6 shadow-lg">
      <h3 className="text-2xl font-bold text-white">Ready to start?</h3>
      <p className="mt-2 text-sm text-indigo-100">Join thousands of developers building amazing products.</p>
      <div className="mt-6 flex gap-2">
        <input
          type="email"
          placeholder="Enter your email"
          className="flex-1 rounded-lg border-0 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-white"
        />
        <button className="rounded-lg bg-white px-4 py-2 text-sm font-medium text-indigo-600 transition-colors hover:bg-indigo-50">
          Subscribe
        </button>
      </div>
    </div>
  )
}

// Gallery Data
const sections: Section[] = [
  {
    id: "cards",
    label: "Cards",
    items: [
      {
        id: "profile-card",
        title: "Profile Card",
        description: "Simple profile card with avatar, name, role, and action buttons.",
        tags: ["profile", "user", "social"],
        preview: <ProfileCard />,
        code: `<div className="w-80 rounded-xl border border-zinc-200 bg-white p-6 shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
  <div className="flex flex-col items-center">
    <div className="h-20 w-20 rounded-full bg-gradient-to-br from-blue-500 to-purple-600" />
    <h3 className="mt-4 text-xl font-semibold text-zinc-900 dark:text-zinc-100">
      Jane Doe
    </h3>
    <p className="text-sm text-zinc-600 dark:text-zinc-400">
      Senior Designer
    </p>
    <div className="mt-6 flex w-full gap-2">
      <button className="flex-1 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-700">
        Follow
      </button>
      <button className="flex-1 rounded-lg border border-zinc-300 bg-white px-4 py-2 text-sm font-medium text-zinc-900 transition-colors hover:bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-100 dark:hover:bg-zinc-700">
        Message
      </button>
    </div>
  </div>
</div>`,
      },
      {
        id: "pricing-card",
        title: "Pricing Card",
        description: "Pricing card with features list and call-to-action button.",
        tags: ["pricing", "subscription", "cta"],
        preview: <PricingCard />,
        code: `<div className="w-80 rounded-xl border border-zinc-200 bg-white p-6 shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
  <div className="mb-4">
    <h3 className="text-lg font-semibold text-zinc-900 dark:text-zinc-100">
      Professional
    </h3>
    <div className="mt-2 flex items-baseline">
      <span className="text-4xl font-bold text-zinc-900 dark:text-zinc-100">
        $29
      </span>
      <span className="ml-1 text-zinc-600 dark:text-zinc-400">/month</span>
    </div>
  </div>
  <ul className="mb-6 space-y-3">
    <li className="flex items-center text-sm text-zinc-700 dark:text-zinc-300">
      <svg className="mr-2 h-4 w-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
      </svg>
      Unlimited projects
    </li>
    {/* Add more features */}
  </ul>
  <button className="w-full rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-blue-700">
    Get Started
  </button>
</div>`,
      },
      {
        id: "stats-card",
        title: "Stats Card",
        description: "Statistics card with multiple metrics and subtle gradient background.",
        tags: ["stats", "analytics", "dashboard"],
        preview: <StatsCard />,
        code: `<div className="w-80 rounded-xl border border-zinc-200 bg-gradient-to-br from-blue-50 to-purple-50 p-6 shadow-sm dark:from-zinc-900 dark:to-zinc-800 dark:border-zinc-700">
  <h3 className="mb-6 text-lg font-semibold text-zinc-900 dark:text-zinc-100">
    Performance
  </h3>
  <div className="grid grid-cols-3 gap-4">
    <div className="text-center">
      <div className="mb-1 text-2xl font-bold text-zinc-900 dark:text-zinc-100">
        12.5K
      </div>
      <div className="text-xs text-zinc-600 dark:text-zinc-400">
        Users
      </div>
    </div>
    <div className="text-center">
      <div className="mb-1 text-2xl font-bold text-zinc-900 dark:text-zinc-100">
        $48K
      </div>
      <div className="text-xs text-zinc-600 dark:text-zinc-400">
        Revenue
      </div>
    </div>
    <div className="text-center">
      <div className="mb-1 text-2xl font-bold text-zinc-900 dark:text-zinc-100">
        +23%
      </div>
      <div className="text-xs text-zinc-600 dark:text-zinc-400">
        Growth
      </div>
    </div>
  </div>
</div>`,
      },
      {
        id: "blog-card",
        title: "Blog Card",
        description: "Article card with image placeholder, title, excerpt, and metadata.",
        tags: ["blog", "article", "content"],
        preview: <BlogCard />,
        code: `<div className="w-80 overflow-hidden rounded-xl border border-zinc-200 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
  <div className="h-40 bg-gradient-to-br from-orange-400 to-pink-500" />
  <div className="p-4">
    <span className="inline-block rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-800 dark:bg-blue-900 dark:text-blue-200">
      Design
    </span>
    <h3 className="mt-2 text-lg font-semibold text-zinc-900 dark:text-zinc-100">
      Building Better Interfaces
    </h3>
    <p className="mt-2 text-sm text-zinc-600 dark:text-zinc-400">
      Learn the fundamentals of creating user-friendly and accessible web
      interfaces with modern design principles.
    </p>
    <div className="mt-4 flex items-center justify-between text-xs text-zinc-500 dark:text-zinc-500">
      <span>5 min read</span>
      <span>Dec 17, 2025</span>
    </div>
  </div>
</div>`,
      },
      {
        id: "cta-card",
        title: "CTA Card",
        description: "Call-to-action card with headline, supporting text, and email input.",
        tags: ["cta", "subscribe", "newsletter"],
        preview: <CTACard />,
        code: `<div className="w-80 rounded-xl border border-zinc-200 bg-gradient-to-br from-indigo-600 to-purple-600 p-6 shadow-lg">
  <h3 className="text-2xl font-bold text-white">Ready to start?</h3>
  <p className="mt-2 text-sm text-indigo-100">
    Join thousands of developers building amazing products.
  </p>
  <div className="mt-6 flex gap-2">
    <input
      type="email"
      placeholder="Enter your email"
      className="flex-1 rounded-lg border-0 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-white"
    />
    <button className="rounded-lg bg-white px-4 py-2 text-sm font-medium text-indigo-600 transition-colors hover:bg-indigo-50">
      Subscribe
    </button>
  </div>
</div>`,
      },
    ],
  },
  {
    id: "navbars",
    label: "Navbars",
    items: [],
  },
  {
    id: "buttons",
    label: "Buttons",
    items: [],
  },
]

// Main Page Component
export default function UIGalleryPage() {
  const [activeSection, setActiveSection] = useState("cards")
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTags, setActiveTags] = useState<string[]>([])

  const currentSection = sections.find((s) => s.id === activeSection)

  // Filter items based on search query and active tags
  const filteredItems = useMemo(() => {
    if (!currentSection) return []

    let items = currentSection.items

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase()
      items = items.filter(
        (item) =>
          item.title.toLowerCase().includes(query) ||
          item.description.toLowerCase().includes(query) ||
          item.tags.some((tag) => tag.toLowerCase().includes(query)),
      )
    }

    // Filter by active tags
    if (activeTags.length > 0) {
      items = items.filter((item) => activeTags.every((tag) => item.tags.includes(tag)))
    }

    return items
  }, [currentSection, searchQuery, activeTags])

  const handleTagToggle = (tag: string) => {
    setActiveTags((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]))
  }

  const totalItems = currentSection?.items.length || 0

  return (
    <div className="flex min-h-screen bg-background font-sans">
      {/* Sidebar */}
      <Sidebar sections={sections} activeSection={activeSection} onSectionChange={setActiveSection} />

      {/* Main Content */}
      <main className="flex-1 p-8">
        {/* Header */}
        <header className="mb-8">
          <h1 className="mb-4 text-4xl font-bold text-foreground">Devwolf UI Gallery</h1>
          <div className="flex items-center gap-4">
            <input
              type="search"
              placeholder="Search components by title, tags, or description..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 rounded-lg border border-input bg-background px-4 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
            />
            <div className="text-sm text-muted-foreground">
              Showing {filteredItems.length} / {totalItems}
            </div>
          </div>
        </header>

        {/* Gallery Grid */}
        {currentSection && currentSection.items.length > 0 ? (
          <GalleryGrid items={filteredItems} activeTags={activeTags} onTagToggle={handleTagToggle} />
        ) : (
          <div className="flex h-64 items-center justify-center rounded-xl border border-dashed border-border">
            <p className="text-muted-foreground">Coming soon...</p>
          </div>
        )}
      </main>
    </div>
  )
}
